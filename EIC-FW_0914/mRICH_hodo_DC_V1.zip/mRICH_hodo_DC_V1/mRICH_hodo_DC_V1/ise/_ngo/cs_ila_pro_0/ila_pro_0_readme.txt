The following files were generated for 'ila_pro_0' in directory
C:\Users\isar\Dropbox\Nalu\Startup\Projects\EIC-Beamtest-FW\mRICH_hodo_DC_V1\mRICH_hodo_DC_V1\ise\_ngo\cs_ila_pro_0\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ila_pro_0.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ila_pro_0.cdc
   * ila_pro_0.ngc
   * ila_pro_0.ucf
   * ila_pro_0.vhd
   * ila_pro_0.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * ila_pro_0.vho

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * ila_pro_0_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * ila_pro_0.gise
   * ila_pro_0.xise

Deliver Readme:
   Readme file for the IP.

   * ila_pro_0_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ila_pro_0_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

