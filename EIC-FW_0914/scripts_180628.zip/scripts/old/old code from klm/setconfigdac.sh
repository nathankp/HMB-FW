cd ..
./setConfig
cd scripts
./sendCMD.py eth0 AF558000
